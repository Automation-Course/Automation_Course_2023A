import java.util.Scanner;
public class Automation_Calculator {

	public static void main(String[] args) {
		boolean flag = false;
		while(flag == false) {// The calculator will run until the flag will change to true.
			Scanner sc = new Scanner(System.in);
			Scanner myScanner = new Scanner(System.in);
			System.out.println("Please choose the calculator convertor: ");
			String calc = "";
			calc = myScanner.nextLine();
			if(calc.contains("stop")) {// An option to stop the calculator by write is the console - stop.
				flag = true;
			}
			else if(calc.contains("binaryToDecimal")) {// The calculator that convert from binary to decimal number.
				while(true) {// The loop will end when there will be a binary number that convert to decimal number.
					System.out.println("Please enter a binary number: ");
					boolean isDecimal = false;
					int binary = 0;
					int decimal = 0;
					binary = sc.nextInt();
					if(binary < 0) {// Condition that checks if a binary number is negative.
						System.out.println("The number is not valid, please try again");
					}
					else {  
						int n = 0;  
						while(true){  
							if(binary == 0){// Condition that print the decimal number.
								System.out.println("The decimal number is: " + decimal);
								isDecimal = true;
								break;  
							} else {// Condition that calculate for each 1 or 0 in the binary number the new number
									// used by Math.pow.
								int temp = binary%10;  
								if(temp == 1 || temp == 0) {
									decimal += temp*Math.pow(2, n);  
									binary = binary/10;  
									n++;
								}
								else {// Condition that checks if the input binary number is valid.
									System.out.println("The number is not a binary number, please try again");
									break;
								}
							}
						}	
					}
					if(isDecimal == true) {// If the calculator succed to convert binary to decimal number - the boolean
										   // isDecimal will turn to true and break from the binaryToDecimal calculator.
						break;
					}
				}// End while loop.
			}// End elseif Binary To decimal calculator.
			else if(calc.contains("decimalToBinary")) {// The calculator that convert from decimal to binary number.	
				while(true) {
					System.out.println("Please enter a decimal number: ");
					int decimal = 0;
					String decimalTemp = "";
					decimalTemp = myScanner.nextLine();
					if(decimalTemp.charAt(0) == '-') {// Condition that checks if the decimal number is negative or not.
						System.out.println("The number is not valid, please try again");
					}
					else if(decimalTemp.charAt(0) == '0') {// Condition that checks if the decimal number is starts
														   // with 0 number or not.
						System.out.println("The number is not valid, please try again");
					}
					else {
						decimal = Integer.parseInt(decimalTemp);// Casting the the decimal number input from string to int. 
						toBinary(decimal);// Function that convert decimal to binary number. 
						break;
					}
				}// End while loop.
			}// End elseif decimal To Binary calculator.
			else {// Condition that happen if the user enters wrong name of calculator to be use.
				System.out.println("Wrong input please try again! ");
			}
		}
	}// End main.

	public static void toBinary(int decimal){// Function that convert decimal to binary number.    
		int binary[] = new int[40];    
		int index = 0;    
		while(decimal > 0){// Loop that organize the decimal number in form of 0 and 1 number in the binary array.    
			binary[index++] = decimal%2;    
			decimal = decimal/2;    
		} 
		System.out.print("The binary number is: ");
		for(int i = index-1;i >= 0;i--){
			// Loop that start from the last index from the end of the numbers that we added to the binary array and 
			// prints the binary number.
			System.out.print(binary[i]);    
		}
		System.out.println();
	}// End function toBinary.   
}// End class Automation_Calculator.
