import java.util.Scanner;

public class Conversion {
	static Scanner reader = new Scanner(System.in);

	public static void startMenu() 
	{
		System.out.println("Please pick an option from the menu\n"
				+ "B - convert binary to decimal number\n"
				+ "D - convert decimal to binary\n"
				+ "E - Exit");

		String choice = reader.nextLine(); // gets user calculator wish 
		switch(choice) // sends wish to the calculator that needs to work by 
		{
		case "B":
		{
			IOBin();
			break;
		}
		case "D":
		{
			IODec();
			break;
		}
		case "E":
		{
			System.out.println("See you next convert! ;)"); // when asked calculator to finish his job 
			break;
		}
		default:
		{
			System.out.println("Invalid menu input"); // wrong input in menu
			startMenu();
			break;
		}
		}
	}
	public static void IOBin() 
	{
		System.out.println("Enter binary number");
		String bin = reader.nextLine();
		int dec =-1;  
		if(bin.length()>32)
			dec = -1;
		else
			dec = bin2dec(bin);
		if(dec == -1) // if input turned to be non-convertable, notify the user and send him request for another binary number 
		{
			System.out.println("Number entered was not valid. Check if your number contains only 0 & 1 and shorter than 32 digits.");
			IOBin();
		}
		else { // if the calculator did covert the number, reveal the number and sends the menu once more for another fun calculations!
			System.out.println("The converted number is "+dec);
			startMenu();
		}
	}
	public static void IODec() 
	{
		System.out.println("Enter decimal number"); 
		String dec = reader.nextLine(); //get decimal number input from user
		String bin="";
		if(dec.length()>9)
			bin = "NV";
		else
			bin = dec2bin(dec);
		if(bin.equals("NV")) 
		{
			System.out.println("Number entered was not valid.Check if you number is shorter than 9 digits.");
			IODec();
		}
		else {
			System.out.println("The converted number is "+bin); //shows the number calculated 
			startMenu();
		}
	}
	public static int bin2dec(String str)  // converts binary number to decimal number  
	{
		int dec = 0;
		for(int i = 0; i < str.length();i++) 
		{
			char atI = str.charAt(i);
			if(!(atI == '1' || atI == '0')) // means input was incorrect 
				return -1;
			if(atI == '1')
				dec += Math.pow(2, str.length()-1-i); // calculates the number by the power of number 2 as we learned at class		
		}
		return dec;
	}
	public static String dec2bin(String str) // converts decimal number to binary number
	{
		String bin = ""; 
		for(int i = 0; i < str.length(); i++) // runs on input and checks contains only numbers
			if(!(str.charAt(i) >= '0' && str.charAt(i) <= '9')) 
				return "NV"; //if does not fit the requirement, returns not valid
		int dec = Integer.parseInt(str);
		while(dec > 0) // divides by 2 and take the rest to the answer 
		{
			bin += dec%2;
			dec=dec/2;
		}
		String ans="";
		for(int i = bin.length()-1; i>=0;i--) //copy answer to the output
			ans+=bin.charAt(i);
		return ans;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Welcome to the best converter EVER!");
		startMenu();
		
	}
}
